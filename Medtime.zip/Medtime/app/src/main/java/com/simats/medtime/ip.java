package com.simats.medtime;

public class ip {

//    static String ipn ="http://14.139.187.229:8081/medtime/Medtime/";
//    static String ipn ="http://14.139.187.229:8081/medtime/";
    static String ipn ="http://180.235.121.245/medtime/Medtime/";
}
