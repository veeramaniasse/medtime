package com.simats.medtime;

public class ip {

    static String ipn ="http://14.139.187.229:8081/Medtime/";
}
